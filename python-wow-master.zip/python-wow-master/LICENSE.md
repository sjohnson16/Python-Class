Everyone is free to download this repository.
Everyone is free to use this repository to learn Python.
Everyone is free to adapt the code examples in this repository for their software projects.
Everyone is free with proper attribution (authorship and link to source) to use the material in any course.

Packaging or selling the educational materials requires permission from the repository's maintainer, Zachary C. Lipton.
